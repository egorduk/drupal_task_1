$(function () {

    Backbone.emulateHTTP = true;

    var Comment = Backbone.Model.extend({
        urlRoot: '/api/comment',
        defaults: {
            txt: null,
            answer_for: 0,
            created_at: null,
            user_id: 0,
            user_name: null,
            user_avatar_url: null,
            user_link: '#'
        }
    });

    var CommentList = Backbone.Collection.extend({
        url: '/api/comments',
        model: Comment,
        comparator: function (model) {
            return model.get("id");
        }
    });

    var CommentView = Backbone.Marionette.ItemView.extend({
        className: 'cm-item',
        template: _.template($('#comment-template').html()),

        initialize: function () {
            this.listenTo(this.model, 'change', this.render);
            this.listenTo(this.model, 'destroy', this.remove);
        },

        events: {
            'mouseenter': 'onMouseEnter',
            'mouseleave': 'onMouseLeave',
            'click .edit': 'onClickEdit',
            'click .delete': 'onClickDelete',
            'click .cm-edit .cancel': 'onCancelEdit',
            'click .cm-edit .save': 'onSaveEdit',
            'click .cm-answer': 'onClickAnswer'
        },

        onMouseEnter: function () {
            this.$el.find('div.cm-actions').show();
        },

        onMouseLeave: function () {
            this.$el.find('div.cm-actions').hide();
        },

        onClickEdit: function () {
            this.$el.find('.cm-txt').hide();
            this.$el.find('.cm-data').hide();
            this.$el.find('.cm-edit').show();
        },

        onCancelEdit: function () {
            this.$el.find('.cm-edit').hide();
            this.$el.find('.cm-txt').show();
            this.$el.find('.cm-data').show();
            this.$el.find('.cm-edit textarea').val(this.model.get("txt"));
        },

        onSaveEdit: function () {
            var txt = this.$el.find('.cm-edit textarea').val();
            this.model.set("txt", txt);

            /*
            this.model.save({txt: txt}, {
                success: function (model, response) {

                },
                error: function (model, response) {
                    cm.onError(response.responseJSON);
                },
                wait: true
            });
            */
        },

        onClickDelete: function () {

            if (confirm("Вы уверены, что хотите удалить сообщение?")) {
                /*
                this.model.destroy({
                    error: function (model, response) {
                        cm.onError(response.responseJSON);
                    },
                    wait: true
                });
                */
                this.remove();
            }
        },

        onClickAnswer: function () {
            cm.viewAdd.focus(this.model);
        },

        render: function () {
            this.$el.attr("id", "cm-item-" + this.model.id);
            this.$el.empty();
            this.$el.html(this.template(this.model.toJSON()));
            return this;
        }
    });

    var CommentsListView = Backbone.Marionette.CollectionView.extend({
        el: $('#comments .cm-list'),
        childView: CommentView,
        onBeforeRender: function () {
            this.$el.find('img.loading').hide();
        }
    });

    var CommentAddView = Backbone.View.extend({
        el: $('#comments .cm-add'),
        template: _.template($('#comment-add-template').html()),

        events: {
            'click .save': 'onClickAdd'
        },

        onClickAdd: function () {

            var textarea = this.$el.find('textarea');

            var val = textarea.val();

            if (val <= 3)
                return;

            /////\[post\d+\|[^\]]+\]/g

            var post = new cm.Comment({
                txt: val,
                created_at: new Date().toMysqlFormat(),
                user_id: 1,
                user_name: 'Патрик',
                user_avatar_url: 'static/50x50.jpg'
            });

            cm.list.add(post);
            textarea.val("");
            cm.navToDiv('cm-item-' + model.id);

            /*
            post.save({}, {
                success: function (model) {
                    console.log("SUCCESS", model);
                    cm.list.add(model);
                    textarea.val("");
                    cm.navToDiv('cm-item-' + model.id);
                },
                error: function (model, response) {
                    cm.onError(response.responseJSON);
                }
            });
            */
        },

        focus: function (model) {
            var textarea = this.$el.find('textarea');
            textarea.val("[post" + model.get("id") + "|" + model.get("user_name") + "], ");
            textarea.focus();
        },

        render: function () {
            this.$el.empty();
            this.$el.html(this.template(this.model.toJSON()));
            return this;
        }
    });

    function scroll() {
        var elAddWrap = $('#comments div.cm-add-wrap');
        var elAdd = $('#comments div.cm-add');
        var elDoc = $(document);
        var elWin = $(window);

        function check() {
            var st = elDoc.scrollTop();
            var wh = elWin.innerHeight();

            var need = (st + wh < elAddWrap.offset().top + elAddWrap.height());

            if (need) {
                elAdd.addClass('fixed');
            } else {
                elAdd.removeClass('fixed');
            }
        }

        check();

        cm.updateScroll = check;

        $(window).scroll(function () {
            check();
        });
    }

    var cm = {};
    cm.list = new CommentList();
    cm.view = new CommentsListView({collection: cm.list});
    cm.viewAdd = new CommentAddView({model: new Comment()});
    cm.Comment = Comment;
    cm.onError = function (response) {
    };
    cm.useScroll = scroll;
    cm.navToDiv = function (id) {
        console.log('nav', id);
        $('html,body').animate({
                scrollTop: $("#" + id).offset().top
            },
            'slow');
        cm.updateScroll();
    };
    window.cm = cm;
});


Date.prototype.toMysqlFormat = function () {
    function twoDigits(d) {
        if (0 <= d && d < 10) return "0" + d.toString();
        if (-10 < d && d < 0) return "-0" + (-1 * d).toString();
        return d.toString();
    }

    return this.getUTCFullYear() + "-" + twoDigits(1 + this.getUTCMonth()) + "-" + twoDigits(this.getUTCDate()) + " " + twoDigits(this.getUTCHours()) + ":" + twoDigits(this.getUTCMinutes()) + ":" + twoDigits(this.getUTCSeconds());
};