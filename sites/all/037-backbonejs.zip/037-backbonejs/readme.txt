1. Скачано с demos.itlessons.info
2. Статья http://www.itlessons.info/javascript/comments-with-backbone-and-marionette/

LINKS:
  http://backbonejs.org/
  http://backbonejs.ru/
  http://marionettejs.com/